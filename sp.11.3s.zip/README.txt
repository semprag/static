Supplementary material for:

De Veaugh-Geiss, Joseph P., Swantje Tönnis, Edgar Onea & Malte Zimmermann. 2018.
That’s not quite it: An experimental investigation of (non-)exhaustivity in clefts.
Semantics and Pragmatics 11(3). https://doi.org/10.3765/sp.11.3

Description of files:

data.RData contains a serialized R data.frame (https://www.r-project.org/)
stimuli.ods contains stimuli in OpenOffice Spreadsheet format
stimuli.xls contains the same stimuli but in Microsoft Excel format

SHA-512 checksums:

ec7a5e33405e4ddcd86472032bff0af31555783c158976375466eb4bb3f86832b374f1c33e1d1c1960a4aec096cbc0092011dc18c2587f30e9b5d9b5f919346f  data.RData
99386d71d55339520374172d08fb2c9212376c98bbfab94f2b85d26183797b38677518e96517bb33dc2c61a7eabb58ae6569921a87ac21d5a7ac413e59edead3  stimuli.ods
77dd0a89fa0a5f8a74d9ff9e899d139a9fc39eac0ea974e845763c8ebf23b52c9e9b4a11e59eae6c4701f79825a65975cc2f2eabd13a5f7530ab789509a8b8a1  stimuli.xls

Compression method:

The sp.11.3s.zip file was created with the command 'zip sp.11.3s.zip README.txt data.RData stimuli.ods stimuli.xls'
